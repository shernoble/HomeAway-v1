//yaha pe sab connections honge
const express=require("express")
const bodyParser=require("body-parser")
const sqlite=require("sqlite3")
const ejs=require("ejs");

const app=express();
app.use(express.static('public'));
// middleware
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));


app.get("/",function(req,res){
    res.render('admin-homepage');
});
app.post("/",function(req,res){
    const dest=req.body.destination;
    const ci=req.body.checkin;
    const co=req.body.checkout;
    const no_guests=req.body.no_guests
    res.render("results",{destination: dest,checkin:ci,checkout:co,no_guests:no_guests});
});

app.get("/views/:pageName",function(req,res){
    res.render(req.params.pageName);
});

app.get("/:pageName",function(req,res){
    res.render(req.params.pageName);
});

app.post("/:pageName",function(req,res){
    const ci=req.body.checkin;
    const co=req.body.checkout;
    res.render(req.params.pageName);
});
// zaroorath nhi
app.post("/confirmation",function(req,res){
    // check if logged in or not
    // function se kare?

});



app.listen(3000,function(){
    console.log("server has started at port 3000.");
});