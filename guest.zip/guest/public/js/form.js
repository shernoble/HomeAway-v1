// validation

function formValidate(){
    // alert("hii");
    let destination=document.getElementById("destination").value;
    let checkin=document.getElementById("check-in").value;
    let checkout=document.getElementById("check-out").value;
    let no_guests=document.getElementById("no_guests").value;
    alert(destination);
    if(destination=="" || checkin=="" ||checkout=="" || no_guests==""){
        alert("all the fields are required to be filled out");
        return false;
    }
    else return true;

};


